# Melhorias aplicadas na revisão de 26/11/2026

Esta revisão mexeu só no relatório e na apresentação. Código, dados, notebook, painel e números ficaram como estavam. O pipeline foi executado de novo do zero, com os 34 testes aprovados, e os números conferem: 665 lutas, 514/146/5, 77,88%, ICs de Wilson, Fisher (OR 2,61) e MAE da previsão.

## Relatório (relatorio/Fase2_UFC_Relatorio.pdf e .docx)

| Mudança | Por quê | Critério |
|---|---|---|
| Nova seção 3.1, "O painel publicado e a leitura de cada tela", com as capturas das abas Panorama, Conferir uma luta, Modelo preditivo e Previsão mensal, cada uma seguida de uma análise | O enunciado pede que você "documente as análises dos dashboards gerados" na parte dos resultados. Até aqui o relatório mostrava gráficos do matplotlib, mas nenhuma tela do painel. | Implementação (1,5) |
| Nova "Ficha de governança dos KPIs" (frequência, responsável, meta operacional e ação quando a regra dispara) | A rubrica pede KPIs "claros, mensuráveis e reproduzíveis". Faltava dizer o que fazer com cada número. As metas são operacionais (quando publicar, quando revisar) e saem dos próprios dados. Por exemplo, a faixa de ±13,5 p.p. corresponde a duas vezes o MAE da referência em 2024. | Métricas (1,0) |
| Resumo executivo no início | Quem avalia precisa ver a resposta e o valor do trabalho já na primeira página. | Métricas e Apresentação |
| Novos números de valor de negócio: das 37 lutas que o modelo sinalizou, 25 eram divergências (67,6%), contra 19,8% ao acaso, ou seja, uma fila de revisão 3,4 vezes mais concentrada. A oscilação mensal também foi explicada pelo tamanho da amostra (cerca de 21 lutas por mês, com desvio de uns 9 p.p.) | A acurácia sozinha não mostra para que o modelo serve no trabalho do analista. Todos os valores saem da matriz de confusão e do CSV mensal que já estavam publicados. | Implementação e Apresentação |
| "Rotina recomendada" na seção 3.9 | Transforma a análise em três hábitos práticos para o analista. | Apresentação |
| Referências reescritas no padrão ABNT, em ordem alfabética, com Wilson (1927) e Hoerl e Kennard (1970) citados no texto | Na Fase 1 você usou ABNT. Na Fase 2 a lista estava fora de ordem e sem "Disponível em/Acesso em", e os métodos estatísticos não tinham a referência original. | Qualidade geral |
| Saiu a seção 3.9 antiga ("Entregas realizadas") | Ela repetia o que já está na 3.8 e na Conclusão. | Clareza |
| Saíram seis quebras de página manuais | Elas deixavam páginas quase vazias depois da inclusão do novo conteúdo. | Forma |
| Ponto de interrogação no título | Agora o título bate com a Fase 1 e com o painel. | Forma |

As seções 3.1 a 3.8 viraram 3.2 a 3.9, e as Figuras 3 a 6 viraram 7 a 10. A referência cruzada à seção 3.7 foi atualizada.

## Apresentação (apresentacao/Fase2_UFC_Apresentacao.pptx e .pdf)

| Mudança | Por quê |
|---|---|
| Novo slide 2, "Resumo", com três números (77,88%, 36,62% e 3,4×) e a recomendação | A rubrica pede linguagem executiva voltada para o valor. Antes, a mensagem principal só aparecia no fim. |
| Novo slide 6, com a captura do painel | A apresentação não mostrava o produto (o dashboard). |
| Slide 10 reescrito: "O modelo concentra a revisão onde importa" | Troca o foco "limites técnicos" pelo valor operacional, sem esconder o limite. |
| O slide de previsão mensal vem antes da conclusão, com a mesma fonte (Arial) e a mesma cor dos demais e com o gráfico | Antes ele estava depois do encerramento e com tipografia diferente. |
| Conclusão em linguagem executiva (Sim / Ressalva / O que não se prova), com os p-valores numa nota técnica | O público executivo precisa da decisão. Os testes continuam visíveis para a banca. |
| Último slide virou "Recomendações e próximos passos" | Fecha a apresentação com ação: as três recomendações e os três próximos passos. |
| Removidas caixas de texto vazias que tinham sobrado no slide da conclusão | Limpeza. |

## O que só você pode fazer (não alterei o repositório)

1. **Ativar o GitHub Pages** (Settings > Pages > main > /docs). Hoje o endereço igorrandrade.github.io/ufc não responde. Com o Pages ativo, o professor abre o dashboard com um clique, sem precisar do Colab. Depois disso, acrescente o link no relatório (seção 3.8) e no último slide.
2. **Conferir as 12 fichas do UFCStats no seu navegador.** O site bloqueia acesso automatizado, mas abre normalmente para uma pessoa. Isso leva cerca de 30 minutos e fecha o objetivo 4 da Fase 1, que hoje está como "parcialmente atendido".
3. **Atualizar o entrega/Fase2_UFC_Final.zip no GitHub** com este pacote, porque o relatório diz que o pacote completo está lá.


## Correções de interpretação — 26/11/2026

- A regra mensal usa a referência acumulada até o mês anterior. Em fevereiro de 2024, 91,30% observado menos 76,30% de referência resulta em 15,00 p.p. O limiar de 13,5 p.p. foi definido retrospectivamente a partir do MAE de 2024; não é intervalo de previsão nem validação prospectiva.
- A concentração de 3,41 vezes é resultado do teste retrospectivo, sem ganho de produtividade medido. Quando o resultado oficial já existe, o fluxo recomendado consulta diretamente as divergências reais.
- A variação binomial foi identificada como ilustração sob hipóteses, sem atribuição causal da oscilação mensal.
- O slide 12 distingue percentuais agregados de 2022–2024 da direção da diferença observada em cada ano. Referências ao número do slide foram sincronizadas.
- Correções aplicadas ao Word, PowerPoint e respectivos PDFs. Dados, modelos e notebook permanecem inalterados.
